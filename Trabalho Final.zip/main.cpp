#include <iostream>
#include <string>
#include <exception>
#include <vector>
#include <fstream>
#include "aluno.h"
#include "funcionario.h"
#include "professor.h"
#include "aluno.cpp"
#include "funcionario.cpp"
#include "professor.cpp"
#include "menu.cpp"

int main(void){
	
	menuPrincipal();

	return 0;
	
}
